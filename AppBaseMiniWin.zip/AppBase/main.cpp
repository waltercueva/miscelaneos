#include "miniwin.h"
using namespace miniwin;
int main() {
	vredimensiona(1200, 800);
	rectangulo(120, 100, 20, 20);	
	texto(152, 142, "Demo!");
	refresca();
	return 0;
}


